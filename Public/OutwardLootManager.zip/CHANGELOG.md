## Changelog

### Release 0.0.3 Version

#### Fixed

-   Changed readme descriptions. Parameters fixes.


### Release 0.0.2 Version

#### Fixed

-   Changed readme descriptions. Table fixes and example parameters.

### Release 0.0.1 Version

-   Initial release.
