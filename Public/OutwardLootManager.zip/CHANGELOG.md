## Changelog

### Release 0.0.2 Version

#### Fixed

-   Readme descriptions. Table fixes and example parameters.

### Release 0.0.1 Version

-   Initial release.
